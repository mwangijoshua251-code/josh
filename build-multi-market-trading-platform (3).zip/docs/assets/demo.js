(function () {
  var A = window.ARENA, KEY = "arena_demo_v1", MARGIN = 1.04;
  var S = { balance: 10000, open: [], hist: [], nextId: 1 };
  try { var raw = JSON.parse(localStorage.getItem(KEY)); if (raw && typeof raw.balance === "number") S = raw; } catch (e) {}
  var save = function () { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} };
  var $ = function (id) { return document.getElementById(id); };
  var sym = (A.byId("R_100") || A.markets[0]).id, digit = 5, tab = "open";
  var usd = function (n, sgn) { return (n < 0 ? "-" : sgn && n > 0 ? "+" : "") + "$" + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
  var cur = function () { return A.byId(sym); };
  var lastDigit = function (m, p) { return Math.round(p * Math.pow(10, m.digits)) % 10; };

  function toast(msg, cls) { var d = document.createElement("div"); d.className = cls || ""; d.textContent = msg; $("toast").appendChild(d); setTimeout(function () { d.remove(); }, 5000); }

  // market list
  function renderList() {
    var html = "", g = "";
    A.markets.forEach(function (m) {
      if (m.market !== g) { g = m.market; html += '<div class="grp">' + g + "</div>"; }
      var c = A.chg(m);
      html += '<div class="mk ' + (m.id === sym ? "on" : "") + '" data-id="' + m.id + '"><div>' + m.name + "<small>" + m.id + '</small></div><div class="r num"><div class="' + (m.price >= m.prev ? "up" : "down") + '">' + A.fmt(m, m.price) + '</div><small class="' + (c >= 0 ? "up" : "down") + '">' + (c >= 0 ? "+" : "") + c.toFixed(2) + "%</small></div></div>";
    });
    $("list").innerHTML = html;
    $("list").querySelectorAll(".mk").forEach(function (e) { e.onclick = function () { sym = e.dataset.id; renderList(); header(); quote(); }; });
  }
  function header() { var m = cur(); $("mname").textContent = m.name; $("msub").textContent = m.market + " · " + m.sub + " · 1s ticks"; }

  // chart
  var cv = $("cv"), ctx = cv.getContext("2d");
  function draw() {
    var m = cur(), dpr = window.devicePixelRatio || 1, w = cv.clientWidth, h = cv.clientHeight;
    if (cv.width !== w * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
    var data = m.hist.slice(-120), padR = 78, padT = 16, padB = 16, cw = w - padR;
    var lo = Math.min.apply(null, data), hi = Math.max.apply(null, data);
    S.open.filter(function (c) { return c.sym === sym; }).forEach(function (c) { lo = Math.min(lo, c.entry); hi = Math.max(hi, c.entry); });
    if (hi === lo) { hi += 1; lo -= 1; } var pad = (hi - lo) * .12; hi += pad; lo -= pad;
    var y = function (p) { return padT + (hi - p) / (hi - lo) * (h - padT - padB); };
    var x = function (i) { return i / Math.max(1, data.length - 1) * (cw - 10); };
    ctx.strokeStyle = "#131b25"; ctx.fillStyle = "#566478"; ctx.font = "11px system-ui"; ctx.lineWidth = 1;
    for (var g = 0; g <= 5; g++) { var p = lo + (hi - lo) * g / 5, yy = y(p); ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(w, yy); ctx.stroke(); ctx.fillText(A.fmt(m, p), cw + 8, yy + 4); }
    var grad = ctx.createLinearGradient(0, 0, 0, h); grad.addColorStop(0, "rgba(47,140,255,.28)"); grad.addColorStop(1, "rgba(47,140,255,0)");
    ctx.beginPath(); data.forEach(function (p, i) { i ? ctx.lineTo(x(i), y(p)) : ctx.moveTo(x(i), y(p)); });
    ctx.strokeStyle = "#2f8cff"; ctx.lineWidth = 2; ctx.stroke();
    ctx.lineTo(x(data.length - 1), h); ctx.lineTo(0, h); ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
    S.open.filter(function (c) { return c.sym === sym; }).forEach(function (c) {
      var yy = y(c.entry); ctx.setLineDash([5, 4]); ctx.strokeStyle = "#f5a524"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(cw, yy); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = "#f5a524"; ctx.fillText("#" + c.id + " entry", 6, yy - 4);
    });
    var last = data[data.length - 1], ly = y(last), up = last >= m.prev; ctx.fillStyle = up ? "#00c390" : "#ff444f"; ctx.fillRect(cw + 2, ly - 9, padR - 4, 18); ctx.fillStyle = "#031"; ctx.font = "bold 11px system-ui"; ctx.fillText(A.fmt(m, last), cw + 6, ly + 4);
    ctx.beginPath(); ctx.arc(x(data.length - 1), ly, 4, 0, 7); ctx.fillStyle = "#fff"; ctx.fill();
  }
  function quote() { var m = cur(), c = A.chg(m); $("mprice").textContent = A.fmt(m, m.price); $("mprice").className = "num " + (m.price >= m.prev ? "up" : "down"); $("mchg").textContent = (c >= 0 ? "+" : "") + c.toFixed(2) + "%"; $("mchg").className = "num " + (c >= 0 ? "up" : "down"); }

  // pricing
  function prob(type, d, ticks) { switch (type) { case "CALL": case "PUT": case "EVEN": case "ODD": return .5; case "OVER": return (9 - d) / 10; case "UNDER": return d / 10; case "MATCH": return .1; case "DIFF": return .9; } return .5; }
  var needsDigit = function (t) { return t === "OVER" || t === "UNDER" || t === "MATCH" || t === "DIFF"; };
  function validity() {
    var t = $("type").value, st = +$("stake").value, dur = Math.round(+$("dur").value);
    if (!(st >= .35)) return "Minimum stake is $0.35"; if (st > 5000) return "Maximum stake is $5,000";
    if (!(dur >= 1 && dur <= 10)) return "Duration must be 1–10 ticks";
    if (t === "OVER" && digit > 8) return "Over: pick a digit from 0 to 8"; if (t === "UNDER" && digit < 1) return "Under: pick a digit from 1 to 9";
    if (st > S.balance) return "Insufficient balance"; return null;
  }
  function payout() { var t = $("type").value, st = +$("stake").value || 0; return Math.round(st / (prob(t, digit) * MARGIN) * 100) / 100; }
  function updateTicket() {
    var t = $("type").value; $("digwrap").style.display = needsDigit(t) ? "block" : "none";
    var p = payout(), st = +$("stake").value || 0, err = validity();
    $("pay").textContent = usd(p); $("prof").textContent = usd(p - st);
    $("buy").disabled = !!err; $("buy").title = err || ""; $("buy").textContent = err && err !== "Insufficient balance" ? err : err ? err : "Buy " + $("type").selectedOptions[0].text.replace(" (digit)", "");
    $("buy").className = "btn " + (t === "PUT" || t === "ODD" || t === "UNDER" || t === "DIFF" ? "btn-down" : "btn-up");
    $("bal").textContent = usd(S.balance);
  }
  $("digits").innerHTML = Array.from({ length: 10 }, function (_, i) { return '<button data-d="' + i + '" class="' + (i === digit ? "on" : "") + '">' + i + "</button>"; }).join("");
  $("digits").onclick = function (e) { var b = e.target.closest("button"); if (!b) return; digit = +b.dataset.d; $("digits").querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); }); updateTicket(); };
  ["type", "stake", "dur"].forEach(function (id) { $(id).oninput = updateTicket; });
  document.querySelectorAll(".quick button").forEach(function (b) { b.onclick = function () { $("stake").value = b.textContent; updateTicket(); }; });

  $("buy").onclick = function () {
    if (validity()) return;
    var m = cur(), t = $("type").value, st = Math.round(+$("stake").value * 100) / 100, dur = Math.round(+$("dur").value);
    S.balance = Math.round((S.balance - st) * 100) / 100;
    S.open.unshift({ id: S.nextId++, sym: sym, name: m.name, type: t, label: $("type").selectedOptions[0].text, digit: needsDigit(t) ? digit : null, stake: st, payout: payout(), entry: m.price, left: dur, dur: dur, digits: m.digits });
    save(); toast("Bought " + $("type").selectedOptions[0].text + " on " + m.name + " · stake " + usd(st)); rows(); updateTicket();
  };

  function settle(c, exit) {
    var m = A.byId(c.sym), d = lastDigit(m, exit), win;
    switch (c.type) { case "CALL": win = exit > c.entry; break; case "PUT": win = exit < c.entry; break; case "EVEN": win = d % 2 === 0; break; case "ODD": win = d % 2 === 1; break; case "OVER": win = d > c.digit; break; case "UNDER": win = d < c.digit; break; case "MATCH": win = d === c.digit; break; default: win = d !== c.digit; }
    var ret = win ? c.payout : 0, profit = Math.round((ret - c.stake) * 100) / 100;
    S.balance = Math.round((S.balance + ret) * 100) / 100;
    S.hist.unshift({ id: c.id, name: c.name, label: c.label, digit: c.digit, stake: c.stake, entry: c.entry, exit: exit, profit: profit, win: win, digits: c.digits, t: Date.now() });
    S.hist = S.hist.slice(0, 100);
    toast(c.label + " · " + c.name + ": " + (win ? "won " : "lost ") + usd(profit, true), win ? "w" : "l");
  }

  document.querySelectorAll(".tabs button").forEach(function (b) { b.onclick = function () { tab = b.dataset.t; document.querySelectorAll(".tabs button").forEach(function (x) { x.classList.toggle("on", x === b); }); rows(); }; });
  function rows() {
    if (tab === "open") {
      $("th").innerHTML = "<tr><th>ID</th><th>Market</th><th>Type</th><th>Stake</th><th>Entry</th><th>Spot</th><th>Ticks left</th><th>Payout</th></tr>";
      $("tb").innerHTML = S.open.length ? S.open.map(function (c) { var m = A.byId(c.sym); return '<tr><td class="muted">#' + c.id + "</td><td>" + c.name + "</td><td>" + c.label + (c.digit !== null ? " " + c.digit : "") + '</td><td class="num">' + usd(c.stake) + '</td><td class="num">' + A.fmt(m, c.entry) + '</td><td class="num">' + A.fmt(m, m.price) + '</td><td class="num">' + c.left + '</td><td class="num">' + usd(c.payout) + "</td></tr>"; }).join("") : '<tr><td colspan="8" class="muted" style="text-align:center;padding:40px">No open positions. Place a trade to get started.</td></tr>';
    } else {
      $("th").innerHTML = "<tr><th>ID</th><th>Market</th><th>Type</th><th>Stake</th><th>Entry</th><th>Exit</th><th>Profit / Loss</th></tr>";
      $("tb").innerHTML = S.hist.length ? S.hist.map(function (h) { var m = { digits: h.digits }; return '<tr><td class="muted">#' + h.id + "</td><td>" + h.name + "</td><td>" + h.label + (h.digit !== null ? " " + h.digit : "") + '</td><td class="num">' + usd(h.stake) + '</td><td class="num">' + A.fmt(m, h.entry) + '</td><td class="num">' + A.fmt(m, h.exit) + '</td><td class="num ' + (h.profit >= 0 ? "up" : "down") + '"><b>' + usd(h.profit, true) + "</b></td></tr>"; }).join("") : '<tr><td colspan="7" class="muted" style="text-align:center;padding:40px">No closed trades yet.</td></tr>';
    }
  }

  $("reset").onclick = function () { if (S.open.length && !confirm("Open positions will be discarded. Reset anyway?")) return; S = { balance: 10000, open: [], hist: [], nextId: 1 }; save(); rows(); updateTicket(); toast("Demo balance reset to $10,000.00"); };

  var n = 0;
  function tick() {
    A.markets.forEach(function (m) {
      var p = A.step(m);
      S.open.forEach(function (c) { if (c.sym === m.id) c.left--; });
    });
    var due = S.open.filter(function (c) { return c.left <= 0; });
    if (due.length) { due.forEach(function (c) { settle(c, A.byId(c.sym).price); }); S.open = S.open.filter(function (c) { return c.left > 0; }); }
    if (due.length || n % 5 === 0) save();
    if (n++ % 3 === 0) renderList();
    quote(); rows(); updateTicket(); draw();
  }
  renderList(); header(); quote(); rows(); updateTicket(); draw();
  setInterval(tick, 1000);
  window.addEventListener("resize", draw);
})();

# Arena Markets — static site (GitHub Pages)

Plain HTML/CSS/JS. No build step.

| File | Purpose |
|---|---|
| `index.html` | Landing page with live simulated ticker |
| `markets.html` | All markets table (filterable) |
| `trade-types.html` | Explains the 8 trade types |
| `payments.html` | USDT / BTC / ETH / M-Pesa limits & fees |
| `demo.html` | Working in-browser demo terminal (virtual $10,000, saved in localStorage) |
| `risk.html` | Risk disclosure & terms **template** (get legal review) |
| `assets/config.js` | **Set `ARENA_APP_URL` here** to link Log in / Sign up to your full app |

## Deploy on GitHub Pages
1. Create a repo and push this project (`git init && git add . && git commit -m "site" && git remote add origin <url> && git push -u origin main`).
2. Repo → **Settings → Pages → Build and deployment → Source: GitHub Actions** (the included workflow publishes `docs/`),
   or choose **Deploy from a branch → main → /docs**.
3. Your site appears at `https://<user>.github.io/<repo>/`.

## Important
GitHub Pages serves static files only. Real logins, the database, deposits/withdrawals and
live settlement need the full Next.js app (the rest of this repo) hosted on a server platform
(Vercel + managed Postgres, Render, Railway, a VPS …). After deploying it, put its URL in
`docs/assets/config.js`.

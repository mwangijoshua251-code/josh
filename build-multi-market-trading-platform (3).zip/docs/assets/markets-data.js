// Shared browser-side market simulator (demo data only — NOT real prices).
(function () {
  var M = [];
  function add(market, sub, id, name, base, digits, vol) { M.push({ market: market, sub: sub, id: id, name: name, base: base, digits: digits, vol: vol }); }
  [["R_10", 10, 6200, 3], ["R_25", 25, 2150, 3], ["R_50", 50, 252, 4], ["R_75", 75, 46500, 4], ["R_100", 100, 1020, 2]].forEach(function (v) { add("Derived", "Volatility Indices", v[0], "Volatility " + v[1] + " Index", v[2], v[3], v[1] / 100); });
  [300, 500, 1000].forEach(function (n) { add("Derived", "Crash/Boom", "BOOM" + n, "Boom " + n + " Index", 9000 + n, 3, 0.3); add("Derived", "Crash/Boom", "CRASH" + n, "Crash " + n + " Index", 8000 + n, 3, 0.3); });
  add("Derived", "Step Indices", "stpRNG", "Step Index", 9850, 1, 0.06);
  [10, 25, 50, 75, 100].forEach(function (v) { add("Derived", "Jump Indices", "JD" + v, "Jump " + v + " Index", 4000 + v * 20, 2, v / 100); });
  [["EURUSD", "EUR/USD", 1.085, 5, .07], ["GBPUSD", "GBP/USD", 1.27, 5, .085], ["USDJPY", "USD/JPY", 152.8, 3, .09], ["USDCHF", "USD/CHF", .905, 5, .07], ["AUDUSD", "AUD/USD", .66, 5, .095], ["USDCAD", "USD/CAD", 1.365, 5, .06], ["EURGBP", "EUR/GBP", .854, 5, .06], ["EURJPY", "EUR/JPY", 165.8, 3, .1], ["GBPJPY", "GBP/JPY", 194, 3, .11], ["USDZAR", "USD/ZAR", 18.4, 4, .15], ["USDMXN", "USD/MXN", 17.1, 4, .14]].forEach(function (f) { add("Forex", "Forex Pairs", "frx" + f[0], f[1], f[2], f[3], f[4]); });
  [["OTC_SPC", "US 500", 5150, .16], ["OTC_DJI", "Wall Street 30", 38900, .14], ["OTC_NDX", "US Tech 100", 18100, .2], ["OTC_FTSE", "UK 100", 7950, .14], ["OTC_GDAXI", "Germany 40", 18300, .16], ["OTC_N225", "Japan 225", 39400, .18], ["OTC_HSI", "Hong Kong 50", 16700, .24]].forEach(function (i) { add("Stock Indices", "Indices", i[0], i[1], i[2], 2, i[3]); });
  [["frxXAUUSD", "Gold/USD", 2350, 2, .15], ["frxXAGUSD", "Silver/USD", 28.5, 4, .28], ["frxXPTUSD", "Platinum/USD", 960, 2, .22], ["BROUSD", "Oil/USD (Brent)", 84.5, 3, .35], ["WTIUSD", "Oil/USD (WTI)", 80.2, 3, .35], ["NGSUSD", "Natural Gas/USD", 2.1, 3, .55]].forEach(function (c) { add("Commodities", "Metals & Energy", c[0], c[1], c[2], c[3], c[4]); });
  [["BTC", 98000, 2, .55], ["ETH", 3400, 2, .65], ["LTC", 85, 2, .7], ["BNB", 590, 2, .6], ["SOL", 165, 2, .9], ["XRP", .62, 4, .8], ["ADA", .58, 4, .85], ["DOGE", .16, 5, .95]].forEach(function (c) { add("Cryptocurrencies", "Crypto", "cry" + c[0] + "USD", c[0] + "/USD", c[1], c[2], c[3]); });
  [["AAPL", "Apple Inc.", 185.4, .28], ["MSFT", "Microsoft Corp.", 415, .26], ["GOOGL", "Alphabet Inc.", 150.3, .3], ["AMZN", "Amazon.com", 180.5, .32], ["META", "Meta Platforms", 495, .38], ["NVDA", "NVIDIA Corp.", 880, .55], ["TSLA", "Tesla Inc.", 175.2, .6], ["NFLX", "Netflix Inc.", 610, .4], ["KO", "Coca-Cola Co.", 60, .15]].forEach(function (s) { add("Stocks", "US Stocks", "OTC_" + s[0], s[1], s[2], 2, s[3]); });

  function gauss() { var u = 1 - Math.random(), v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  var SEC_YEAR = 31536000;
  M.forEach(function (m) { m.price = m.base * (1 + (Math.random() - .5) * .02); m.open = m.price; m.prev = m.price; m.hist = []; m.sigma = m.vol / Math.sqrt(SEC_YEAR) * 90; /* accelerated so demo moves visibly */ });
  function step(m) {
    m.prev = m.price;
    var r = m.sigma * gauss();
    if (/^BOOM/.test(m.id) && Math.random() < 1 / parseInt(m.id.slice(4))) r += 0.004;
    if (/^CRASH/.test(m.id) && Math.random() < 1 / parseInt(m.id.slice(5))) r -= 0.004;
    if (/^JD/.test(m.id) && Math.random() < 1 / 120) r += (Math.random() < .5 ? -1 : 1) * m.sigma * 12;
    m.price = +(m.price * Math.exp(r)).toFixed(m.digits);
    m.hist.push(m.price); if (m.hist.length > 300) m.hist.shift();
    return m.price;
  }
  for (var i = 0; i < 150; i++) M.forEach(step);
  M.forEach(function (m) { m.open = m.hist[0]; });
  window.ARENA = { markets: M, step: step, byId: function (id) { return M.filter(function (m) { return m.id === id; })[0]; },
    fmt: function (m, p) { return Number(p).toLocaleString("en-US", { minimumFractionDigits: m.digits, maximumFractionDigits: m.digits }); },
    chg: function (m) { return (m.price - m.open) / m.open * 100; } };
})();
